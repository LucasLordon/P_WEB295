<script setup>

</script>

<template>
          <p>Le site sert à apprendre vue, il simule une librairie en ligne et à été réaliser par Sofiene et Lucas dans le cadre du module I-294.</p>
</template>

<style scoped>

p {
  display: flex;
  justify-content: center;
}

</style>

