let dataCategory = [
    {
        id: 1,
        created: new Date(),
        category: "Dystopie"
    },
    {
        id: 2,
        created: new Date(),
        category: "Fantasy"},
    {
        id: 3,
        created: new Date(),
        category: "Roman classique"},
    {
        id: 4,
        created: new Date(),
        category: "Littérature jeunesse"},
    {
        id: 5,
        created: new Date(),
        category: "Roman historique"},
    {
        id: 6,
        created: new Date(),
        category: "Aventure"
    }
]

export { dataCategory };