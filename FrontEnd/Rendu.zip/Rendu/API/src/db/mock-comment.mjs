let dataComment = [
    {
        id: 1,
        created: new Date(),
        comment: "Pas mal",
        appreciation:2,
        books_id:1,
        com_customers_id:1
    },
    {
        id: 2,
        created: new Date(),
        comment: "Bof",
        appreciation:3,
        books_id: 1,
        com_customers_id: 2
    },
    {
        id: 3,
        created: new Date(),
        comment: "Trop long",
        appreciation:1,
        books_id: 1,
        com_customers_id: 3
    },
    {
        id: 4,
        created: new Date(),
        comment: "J'addors",
        appreciation:5,
        books_id: 4,
        com_customers_id: 4
    },
    {
        id: 5,
        created: new Date(),
        comment: "Je suis fan",
        appreciation:1,
        books_id: 5,
        com_customers_id: 5
    },
    {
        id: 6,
        created: new Date(),
        comment: "Bon titre",
        appreciation:3,
        books_id: 6,
        com_customers_id: 6
    }
]

export { dataComment };