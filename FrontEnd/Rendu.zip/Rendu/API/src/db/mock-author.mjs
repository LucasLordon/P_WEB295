let dataAuthor = [

    {
        id: 1,
        created: new Date(),
        name: "David",
        firstName: "Gogins",
  
    },
    {
        id: 2,
        created: new Date(),
        name: "Tolkien",
        firstName: "J.R.R.",

    },
    {
        id: 3,
        created: new Date(),
        name: "Rowling",
        firstName: "J.K.",

    },
    {
        id: 4,
        created: new Date(),
        name: "Austen",
        firstName: "Jane",
    },
    {
        id: 5,
        created: new Date(),
        name: " de Saint-Exupéry",
        firstName: "Antoine",
    },
    {
        id: 6,
        created: new Date(),
        name: "Hugo",
        firstName: "Victor",
    },
    {
        id: 7,
        created: new Date(),
        name: "Autheur",
        firstName: " par default",
  
    }
];

export { dataAuthor };
